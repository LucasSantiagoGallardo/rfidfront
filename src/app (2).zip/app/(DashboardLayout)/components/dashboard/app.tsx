'use client';

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AppBar, Toolbar, Box, Typography, Grid, Divider, CircularProgress, Paper,
  IconButton, Tooltip, TextField, Switch, FormControlLabel, Alert, Button, Chip,
  Stack, InputAdornment, List, ListItem, ListItemText, Select, MenuItem
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import DownloadIcon from '@mui/icons-material/Download';
import SearchIcon from '@mui/icons-material/Search';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import SecurityIcon from '@mui/icons-material/Security';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RTooltip,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, AreaChart, Area, Legend
} from 'recharts';
import BarrieControl from './barrieControl';
const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://10.10.67.195';

type RawRegistro = {
  id?: number | string;
  fecha?: string;
  hora?: string;
  nombre?: string;
  apellido?: string;
  dni?: string | number;
  llave?: string;
  barrera?: string;
  resultado?: string | boolean | number | null;
};

type Estado = '' | 'permitido' | 'denegado' | 'desconocido';

type KPI = { label: string; value: string | number; };

const fmtDate = (d: Date) => d.toISOString().slice(0, 10);
const maskDni = (d?: string | number) => !d ? '—' : String(d).replace(/(\d{3})\d+(\d{2})$/, '$1***$2');
const toNum = (v: any) => Number.isFinite(Number(v)) ? Number(v) : 0;

function normalizeDate(fecha?: string) {
  if (!fecha) return '';
  return fecha.includes('-') ? fecha : fecha.split('/').reverse().join('-');
}
function parseTs(fecha?: string, hora?: string): number {
  if (!fecha) return 0;
  const f = normalizeDate(fecha);
  const iso = `${f}T${hora || '00:00:00'}`;
  const t = Date.parse(iso);
  return Number.isNaN(t) ? 0 : t;
}
function normalizarResultado(v: RawRegistro['resultado']): 'permitido' | 'denegado' | 'desconocido' {
  const s = String(v ?? '').trim().toLowerCase();
  if (['permitido','ok','true','1','allowed','success','aprobado'].includes(s)) return 'permitido';
  if (['denegado','false','0','rejected','fail','denied','rechazado','error'].includes(s)) return 'denegado';
  return 'desconocido';
}
const isEntrada = (b?: string) => !!b && /_in$/i.test(b);
const isSalida  = (b?: string) => !!b && /_out$/i.test(b);

// ===== CSV =====
function exportCSV(rows: RawRegistro[], filename: string) {
  const headers = ['fecha','hora','nombre','apellido','dni','llave','barrera','resultado'] as const;
  const esc = (v: any) => `"${String(v ?? '').replaceAll('"', '""')}"`;
  const csv = [
    headers.join(','),
    ...rows.map(r => headers.map(h => esc((r as any)[h])).join(','))
  ].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

function EstadoBadge({ value }: { value: RawRegistro['resultado'] }) {
  const res = normalizarResultado(value);
  const color = res === 'permitido' ? 'success.main' : res === 'denegado' ? 'error.main' : 'warning.main';
  const Icon = res === 'permitido' ? CheckCircleIcon : res === 'denegado' ? CancelIcon : HelpOutlineIcon;
  return (
    <Stack direction="row" spacing={0.5} alignItems="center" sx={{ color }}>
      <Icon fontSize="small" />
      <Typography variant="body2" sx={{ fontWeight: 600, textTransform: 'capitalize' }}>{res}</Typography>
    </Stack>
  );
}

export default function App() {
  // Filtros
  const today = new Date();
  const startDefault = new Date(today); startDefault.setDate(startDefault.getDate() - 6);
  const [dateFrom, setDateFrom] = useState(fmtDate(startDefault));
  const [dateTo, setDateTo] = useState(fmtDate(today));
  const [q, setQ] = useState('');
  const [estado, setEstado] = useState<Estado>('');
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [maskPII, setMaskPII] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    return localStorage.getItem('adeco_maskPII') !== '0';
  });

  // Filtro por barrera (multi)
  const [barFilter, setBarFilter] = useState<string[]>([]); // vacío = todas

  // Datos
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [registros, setRegistros] = useState<RawRegistro[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const debounceRef = useRef<number | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') localStorage.setItem('adeco_maskPII', maskPII ? '1' : '0');
  }, [maskPII]);

  const fetchData = useCallback(async (signal?: AbortSignal) => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ limit: '1500' });
      if (q.trim()) params.set('q', q.trim());
      if (estado) params.set('estado', estado);
      if (dateFrom) params.set('date_from', dateFrom);
      if (dateTo) params.set('date_to', dateTo);

      const res = await fetch(`${API_URL}/get_registros.php?${params.toString()}`, { signal });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const text = await res.text();
      let rows: RawRegistro[] = [];
      try { rows = JSON.parse(text); }
      catch { throw new Error('Respuesta no es JSON válido'); }

      setRegistros(Array.isArray(rows) ? rows : []);
    } catch (e: any) {
      if (e?.name === 'AbortError') return;  // no mostrar "signal aborted"
      setError(e?.message ?? 'Error al cargar datos');
    } finally {
      setLoading(false);
    }
  }, [q, estado, dateFrom, dateTo]);

  // Carga inicial + refresh
  useEffect(() => {
    const ac = new AbortController();
    if (debounceRef.current) window.clearTimeout(debounceRef.current);
    debounceRef.current = window.setTimeout(() => { fetchData(ac.signal); }, 300);
    return () => { ac.abort(); if (debounceRef.current) window.clearTimeout(debounceRef.current); };
  }, [fetchData]);

  useEffect(() => {
    if (autoRefresh) {
      timerRef.current && clearInterval(timerRef.current);
      timerRef.current = setInterval(() => fetchData().catch(() => {}), 30000);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [autoRefresh, fetchData]);

  // ===== Barreras disponibles (dinámico) =====
  const allBarriers = useMemo(() => {
    const set = new Set<string>();
    registros.forEach(r => r.barrera && set.add(r.barrera));
    // Orden sugerido
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [registros]);

  // Conjunto de datos activo para KPIs y charts (respeta filtro de barreras)
  const dataFiltered = useMemo(() => {
    if (!barFilter.length) return registros;
    const allow = new Set(barFilter);
    return registros.filter(r => r.barrera && allow.has(r.barrera));
  }, [registros, barFilter]);

  // ===== Derivados =====
  const total = dataFiltered.length;
  const permitidos = dataFiltered.filter(r => normalizarResultado(r.resultado) === 'permitido').length;
  const denegados = dataFiltered.filter(r => normalizarResultado(r.resultado) === 'denegado').length;
  const pctOk = total ? Math.round((permitidos / total) * 100) : 0;
  const llavesUnicas = new Set(dataFiltered.map(r => r.llave).filter(Boolean)).size;
  const usuariosUnicos = new Set(dataFiltered.map(r => String(r.dni ?? '')).filter(Boolean)).size;
  const barrerasActivas = new Set(dataFiltered.map(r => r.barrera).filter(Boolean)).size;

  const kpis: KPI[] = [
    { label: 'Eventos', value: total },
    { label: 'Permisos', value: `${pctOk}%` },
    { label: 'Denegados', value: denegados },
    { label: 'Llaves únicas', value: llavesUnicas },
    { label: 'Usuarios únicos', value: usuariosUnicos },
    { label: 'Barreras activas', value: barrerasActivas },
  ];

  // Pie Permitidos vs Denegados
  const pieData = useMemo(() => ([
    { name: 'Permitidos', value: permitidos },
    { name: 'Denegados', value: denegados },
  ]), [permitidos, denegados]);

  const PIE_COLORS = ['#2e7d32', '#c62828'];

  // Top barreras por denegados (en el subconjunto filtrado)
  const topBarreras = useMemo(() => {
    const m = new Map<string, number>();
    dataFiltered.forEach(r => {
      if (normalizarResultado(r.resultado) === 'denegado') {
        const b = r.barrera || '—';
        m.set(b, (m.get(b) || 0) + 1);
      }
    });
    return Array.from(m.entries())
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 8);
  }, [dataFiltered]);

  // Actividad por hora (dos series: entrada/salida, según _in/_out)
  const actividadHora = useMemo(() => {
    const arr = Array.from({ length: 24 }, (_, h) => ({ name: `${String(h).padStart(2, '0')}:00`, entrada: 0, salida: 0 }));
    dataFiltered.forEach(r => {
      const h = toNum(String(r.hora || '00:00').slice(0, 2));
      if (h >= 0 && h < 24) {
        if (isEntrada(r.barrera)) arr[h].entrada += 1;
        else if (isSalida(r.barrera)) arr[h].salida += 1;
        else arr[h].entrada += 1; // fallback
      }
    });
    return arr;
  }, [dataFiltered]);

  // Alertas recientes (denegados)
  const alertas = useMemo(() => {
    return dataFiltered
      .filter(r => normalizarResultado(r.resultado) === 'denegado')
      .sort((a, b) => parseTs(b.fecha, b.hora) - parseTs(a.fecha, a.hora))
      .slice(0, 8);
  }, [dataFiltered]);

  // Tabla: últimos eventos (sin filtrar para que sigas viendo todo; cambia a dataFiltered si querés)
  const recientes = useMemo(() => {
    return [...dataFiltered].sort((a, b) => parseTs(b.fecha, b.hora) - parseTs(a.fecha, a.hora)).slice(0, 40);
  }, [dataFiltered]);

  const columns: GridColDef[] = [
    {
      field: 'ts',
      headerName: 'Fecha',
      width: 160,
      valueGetter: (params) => parseTs(params?.row?.fecha, params?.row?.hora),
      sortComparator: (a, b) => (a as number) - (b as number),
      renderCell: (params) => (
        <Stack spacing={0} sx={{ py: 0.5 }}>
          <Typography variant="body2" sx={{ lineHeight: 1.2 }}>
            {params?.row?.fecha || '—'}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            {params?.row?.hora || ''}
          </Typography>
        </Stack>
      ),
    },
    { field: 'nombre', headerName: 'Nombre', width: 160 },
    { field: 'apellido', headerName: 'Apellido', width: 160 },
    {
      field: 'dni',
      headerName: 'DNI',
      width: 140,
      valueGetter: (params) => params?.row?.dni ?? '',
      renderCell: (params) => maskPII ? maskDni(params?.value) : (params?.value || '—'),
    },
    { field: 'llave', headerName: 'Llave', width: 140 },
    { field: 'barrera', headerName: 'Barrera', width: 160 },
    {
      field: 'resultado',
      headerName: 'Resultado',
      width: 150,
      sortable: true,
      renderCell: (params) => <EstadoBadge value={params?.row?.resultado} />,
    },
  ];
  


  // ===== Toolbar =====
  const toolbar = (
    <Stack direction="row" spacing={1} sx={{ flexWrap: 'wrap', alignItems: 'center' }}>
      <TextField
        size="small"
        placeholder="Buscar por nombre, DNI, llave, barrera…"
        value={q}
        onChange={(e) => setQ(e.target.value)}
        InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
        sx={{ minWidth: 280 }}
      />

      {/* Filtro de estado */}
      {['', 'permitido', 'denegado', 'desconocido'].map((val) => (
        <Chip
          key={val || 'todos'}
          label={val || 'Todos'}
          color={estado === (val as Estado) ? 'primary' : 'default'}
          onClick={() => setEstado(val as Estado)}
          variant={estado === (val as Estado) ? 'filled' : 'outlined'}
          sx={{ textTransform: 'capitalize' }}
        />
      ))}

      {/* Rango de fechas */}
      <TextField
        label="Desde" type="date" size="small" value={dateFrom}
        onChange={(e) => setDateFrom(e.target.value)} InputLabelProps={{ shrink: true }}
      />
      <TextField
        label="Hasta" type="date" size="small" value={dateTo}
        onChange={(e) => setDateTo(e.target.value)} InputLabelProps={{ shrink: true }}
      />

      {/* Barreras (multi-select) */}
      <Select
        multiple
        size="small"
        displayEmpty
        value={barFilter}
        onChange={(e) => setBarFilter(typeof e.target.value === 'string' ? e.target.value.split(',') : (e.target.value as string[]))}
        renderValue={(selected) =>
          selected.length === 0 ? 'Todas las barreras' : (selected as string[]).join(', ')
        }
        sx={{ minWidth: 220 }}
      >
        <MenuItem value="" disabled>Seleccionar barreras…</MenuItem>
        {allBarriers.map(b => (
          <MenuItem key={b} value={b}>{b} {isEntrada(b) ? '• Entrada' : isSalida(b) ? '• Salida' : ''}</MenuItem>
        ))}
      </Select>

      <Divider flexItem orientation="vertical" />
      <Tooltip title="Exportar CSV (rango actual)">
        <span>
          <Button
            variant="outlined"
            startIcon={<DownloadIcon />}
            disabled={!recientes.length}
            onClick={() => exportCSV(recientes, `accesos_${dateFrom}_${dateTo}.csv`)}
          >
            Exportar CSV
          </Button>
        </span>
      </Tooltip>
      <Tooltip title="Actualizar ahora">
        <span>
          <IconButton onClick={() => fetchData()} disabled={loading}>
            <RefreshIcon />
          </IconButton>
        </span>
      </Tooltip>
      <FormControlLabel
        control={<Switch checked={autoRefresh} onChange={(e) => setAutoRefresh(e.target.checked)} />}
        label="Auto-Refresh"
      />
      <FormControlLabel
        control={<Switch checked={maskPII} onChange={(e) => setMaskPII(e.target.checked)} />}
        label="Enmascarar DNI"
      />
    </Stack>
  );

  // ===== Render =====
  return (
    <Box sx={{ minHeight: '100vh', bgcolor: (t) => t.palette.grey[50] }}>
      <AppBar elevation={0} color="default" position="sticky" sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Toolbar sx={{ gap: 2, flexWrap: 'wrap' }}>
          <Typography variant="h6" sx={{ fontWeight: 700, flexGrow: 1, display: 'flex', alignItems: 'center', gap: 1 }}>
            <SecurityIcon /> ADECO • Control de Accesos
          </Typography>
          {toolbar}
        </Toolbar>
      </AppBar>

      <Box sx={{ p: { xs: 2, md: 3 } }}>
        {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}

        {loading ? (
          <Box display="flex" justifyContent="center" alignItems="center" height={260}>
            <CircularProgress />
          </Box>
        ) : (
          <>
            {/* KPIs */}
            <Grid container spacing={2} mb={1}>
              {kpis.map((k) => (
                <Grid item xs={12} sm={6} md={4} lg={2} key={k.label}>
                  <Paper elevation={2} sx={{ p: 2, borderRadius: 2 }}>
                    <Typography variant="overline" color="text.secondary">{k.label}</Typography>
                    <Typography variant="h5" fontWeight={700}>{k.value}</Typography>
                  </Paper>
                </Grid>
              ))}
            </Grid>

 {/* Control de barreras (FastAPI) */}
 <Grid container spacing={2} mb={1}>
 <Grid item xs={12}>
    <BarrieControl />
  </Grid>
  </Grid>





            <Grid container spacing={2}>
              {/* Pie Permitidos vs Denegados */}
              <Grid item xs={12} md={4}>
                <Paper elevation={2} sx={{ p: 2, height: '100%' }}>
                  <Typography variant="h6" fontWeight={700} mb={1}>Estado de Accesos</Typography>
                  {total === 0 ? (
                    <Typography variant="body2" color="text.secondary">Sin datos para el rango/ filtro actual.</Typography>
                  ) : (
                    <Box sx={{ width: '100%', height: 260 }}>
                      <ResponsiveContainer>
                        <PieChart>
                          <Pie data={pieData} dataKey="value" nameKey="name" innerRadius={60} outerRadius={100}>
                            {pieData.map((_, i) => <Cell key={i} fill={['#2e7d32', '#c62828'][i % 2]} />)}
                          </Pie>
                          <RTooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </Box>
                  )}
                </Paper>
              </Grid>

           
              {/* Actividad por hora (Entrada vs Salida) */}
              <Grid item xs={12} md={8}>
                <Paper elevation={2} sx={{ p: 2, height: '100%' }}>
                  <Typography variant="h6" fontWeight={700} mb={1}>Actividad por hora</Typography>
                  <Box sx={{ width: '100%', height: 260 }}>
                    <ResponsiveContainer>
                      <AreaChart data={actividadHora} margin={{ top: 10, right: 10, left: 0, bottom: 10 }}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis allowDecimals={false} />
                        <RTooltip />
                        <Legend />
                        <Area type="monotone" dataKey="entrada" name="Entrada" />
                        <Area type="monotone" dataKey="salida"  name="Salida" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </Box>
                </Paper>
              </Grid>

              {/* Alertas recientes (denegados) */}
              <Grid item xs={12} md={6}>
                <Paper elevation={2} sx={{ p: 2, height: '100%' }}>
                  <Typography variant="h6" fontWeight={700} mb={1}>Alertas recientes (denegados)</Typography>
                  {alertas.length === 0 ? (
                    <Typography variant="body2" color="text.secondary">Sin accesos denegados en el rango/filtro.</Typography>
                  ) : (
                    <List dense>
                      {alertas.map((r, idx) => (
                        <ListItem key={`${r.fecha}-${r.hora}-${idx}`} divider>
                          <ListItemText
                            primary={`${r.nombre ?? ''} ${r.apellido ?? ''}`.trim() || '—'}
                            secondary={`${r.fecha ?? ''} ${r.hora ?? ''} • ${r.barrera || '—'} • ${r.llave || 'sin llave'}`}
                          />
                          <Chip color="error" size="small" label="Denegado" />
                        </ListItem>
                      ))}
                    </List>
                  )}
                </Paper>
              </Grid>

              {/* Últimos accesos (tabla) */}
              <Grid item xs={12} md={6}>
                <Paper elevation={2} sx={{ p: 2 }}>
                  <Stack direction="row" alignItems="center" justifyContent="space-between" mb={1}>
                    <Typography variant="h6" fontWeight={700}>Últimos accesos</Typography>
                    <Chip size="small" label={`${total} eventos`} />
                  </Stack>
                  <div style={{ width: '100%' }}>
                    <DataGrid
                      rows={recientes}
                      columns={columns}
                      getRowId={(row) => (row.id ?? `${row.fecha ?? ''}-${row.hora ?? ''}-${row.llave ?? ''}`) as any}
                      autoHeight
                      density="compact"
                      disableRowSelectionOnClick
                      sx={{
                        border: 0,
                        '& .MuiDataGrid-row:hover': { bgcolor: 'action.hover' },
                        '& .MuiDataGrid-columnHeaderTitle': { fontWeight: 'bold' },
                        fontSize: 13,
                      }}
                      pageSizeOptions={[10, 20, 40]}
                      initialState={{
                        pagination: { paginationModel: { pageSize: 10, page: 0 } },
                        sorting: { sortModel: [{ field: 'ts', sort: 'desc' }] },
                      }}
                    />
                  </div>
                </Paper>
              </Grid>
            </Grid>
          </>
        )}
      </Box>
    </Box>
  );
}
