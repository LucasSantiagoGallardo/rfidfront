import { NextResponse } from 'next/server';
import { pool } from '@/lib/db';
import { readJSON } from '@/lib/request';

export async function POST(request: Request) {
  try {
    const sub = await readJSON<any>(request);
    if (!sub?.endpoint) return NextResponse.json({ error: 'Suscripción inválida' }, { status: 400 });
    await pool.query(`
      CREATE TABLE IF NOT EXISTS push_subscriptions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        endpoint TEXT NOT NULL,
        endpoint_md5 CHAR(32) GENERATED ALWAYS AS (MD5(endpoint)) STORED,
        p256dh VARCHAR(255) NULL,
        auth VARCHAR(255) NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_endpoint_md5 (endpoint_md5)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
    `);
    await pool.query(
      'INSERT INTO push_subscriptions (endpoint, p256dh, auth) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE p256dh=VALUES(p256dh), auth=VALUES(auth)',
      [sub.endpoint, sub.keys?.p256dh || null, sub.keys?.auth || null]
    );
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    console.error('POST /api/push/save error', e);
    return NextResponse.json({ error: 'Error guardando suscripción' }, { status: 500 });
  }
}
