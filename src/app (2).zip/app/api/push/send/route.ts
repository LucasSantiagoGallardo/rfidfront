import { NextResponse } from 'next/server';
import webpush from 'web-push';
import { pool } from '@/lib/db';
import { readJSON } from '@/lib/request';

const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY || '';
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY || '';
const VAPID_SUBJECT = process.env.VAPID_SUBJECT || 'mailto:admin@example.com';

webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);

export async function POST(request: Request) {
  try {
    const payload = await readJSON<any>(request);
    const [rows]: any = await pool.query('SELECT endpoint, p256dh, auth FROM push_subscriptions');
    let sent = 0;
    await Promise.all(rows.map(async (r: any) => {
      try {
        await webpush.sendNotification({
          endpoint: r.endpoint,
          keys: { p256dh: r.p256dh, auth: r.auth }
        } as any, JSON.stringify(payload));
        sent++;
      } catch (e: any) {
        if (e?.statusCode === 410 || e?.statusCode === 404) {
          await pool.query('DELETE FROM push_subscriptions WHERE endpoint = ?', [r.endpoint]);
        } else {
          console.warn('Push error:', e?.message);
        }
      }
    }));
    return NextResponse.json({ sent });
  } catch (e: any) {
    console.error('POST /api/push/send error', e);
    return NextResponse.json({ error: 'Error enviando push' }, { status: 500 });
  }
}
