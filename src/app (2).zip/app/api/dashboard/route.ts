import { NextResponse } from 'next/server';
import { pool } from '@/lib/db';

export async function GET() {
  try {
    const [[hist]]: any = await pool.query('SELECT COUNT(*) AS total FROM hist');
    const [[users]]: any = await pool.query('SELECT COUNT(*) AS total FROM users');
    const [[tags]]: any = await pool.query('SELECT COUNT(*) AS total FROM tags');
    return NextResponse.json({
      usuarios: users.total,
      tags: tags.total,
      accesos: hist.total
    });
  } catch (e: any) {
    console.error('GET /api/dashboard error', e);
    return NextResponse.json({ error: 'Error obteniendo métricas' }, { status: 500 });
  }
}
