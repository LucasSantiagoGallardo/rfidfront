import { NextResponse } from 'next/server';
import { pool } from '@/lib/db';
import { readJSON } from '@/lib/request';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = Math.min(parseInt(searchParams.get('limit') || '100'), 500);
    const [rows] = await pool.query('SELECT id, username, email, role, created_at FROM users ORDER BY id DESC LIMIT ?', [limit]);
    return NextResponse.json(rows);
  } catch (e: any) {
    console.error('GET /api/users error', e);
    return NextResponse.json({ error: 'Error al obtener usuarios' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await readJSON<{ dni?: string; email?: string }>(request);
    if (!body.dni && !body.email) {
      return NextResponse.json({ error: 'dni o email requerido' }, { status: 400 });
    }
    if (body.dni) {
      const [rows] = await pool.query('SELECT * FROM users WHERE dni = ?', [body.dni]);
      if ((rows as any[]).length) return NextResponse.json((rows as any[])[0]);
      return NextResponse.json({ error: 'DNI no encontrado' }, { status: 404 });
    } else {
      const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [body.email]);
      if ((rows as any[]).length) return NextResponse.json((rows as any[])[0]);
      return NextResponse.json({ error: 'Email no encontrado' }, { status: 404 });
    }
  } catch (e: any) {
    console.error('POST /api/users error', e);
    return NextResponse.json({ error: e.message || 'Error en el servidor' }, { status: 500 });
  }
}
