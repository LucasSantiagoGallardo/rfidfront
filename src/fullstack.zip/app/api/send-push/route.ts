import { NextRequest, NextResponse } from "next/server";
// TODO: Implementar endpoint send-push en Node.js manteniendo el JSON del PHP. 
export async function GET() { return NextResponse.json({ error: "Not Implemented: GET send-push" }, { status: 501 }); }
export async function POST() { return NextResponse.json({ error: "Not Implemented: POST send-push" }, { status: 501 }); }
export async function PUT() { return NextResponse.json({ error: "Not Implemented: PUT send-push" }, { status: 501 }); }
export async function DELETE() { return NextResponse.json({ error: "Not Implemented: DELETE send-push" }, { status: 501 }); }
