'use client';
import React, { useEffect, useMemo, useState } from 'react';
import { Box, Grid, Paper, Typography } from '@mui/material';
import BuscadorGlobal from './components/dashboard/BuscadorGlobal';
import QuickSummary from './components/dashboard/QuickSummary';
import KeyStatusChart from './components/dashboard/KeyStatusChart';
import RecentUsersTable from './components/dashboard/RecentUsersTable';

/**
 * Página principal del Dashboard.
 * Reemplaza las llamadas .php por /api/* de Next.
 */
export default function DashboardPage() {
  const [q, setQ] = useState('');
  const [estado, setEstado] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [barrera, setBarrera] = useState('');
  const [dni, setDni] = useState('');

  const params = useMemo(() => {
    const p = new URLSearchParams();
    if (q) p.set('q', q);
    if (estado) p.set('estado', estado);
    if (dateFrom) p.set('date_from', dateFrom);
    if (dateTo) p.set('date_to', dateTo);
    if (barrera) p.set('barrera', barrera);
    if (dni) p.set('dni', dni);
    return p;
  }, [q, estado, dateFrom, dateTo, barrera, dni]);

  return (
    <Box sx={{ p: { xs: 2, md: 3 } }}>
      <Typography variant="h4" fontWeight={700} mb={2}>
        Panel de Accesos
      </Typography>

      <Paper sx={{ p: 2, mb: 2 }} elevation={1}>
        <BuscadorGlobal
          q={q} onQ={setQ}
          estado={estado} onEstado={setEstado}
          dateFrom={dateFrom} onDateFrom={setDateFrom}
          dateTo={dateTo} onDateTo={setDateTo}
          barrera={barrera} onBarrera={setBarrera}
          dni={dni} onDni={setDni}
        />
      </Paper>

      <Grid container spacing={2}>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2, height: '100%' }} elevation={1}>
            <QuickSummary dateFrom={dateFrom} dateTo={dateTo} />
          </Paper>
        </Grid>
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 2, height: '100%' }} elevation={1}>
            <KeyStatusChart dateFrom={dateFrom} dateTo={dateTo} />
          </Paper>
        </Grid>
      </Grid>

      <Paper sx={{ p: 2, mt: 2 }} elevation={1}>
        <RecentUsersTable params={params} />
      </Paper>
    </Box>
  );
}
