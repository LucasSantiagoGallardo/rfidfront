
'use client';

import PageContainer from './components/container/PageContainer';
 import Dashboard2 from '../(DashboardLayout)/components/dashboard/app';

const Dashboard = () => {
  return (
    <PageContainer title="Gestión de Usuarios" description="Administración de usuarios del sistema">
        
      <Dashboard2/>        
      
    </PageContainer>
  );
};

export default Dashboard;
