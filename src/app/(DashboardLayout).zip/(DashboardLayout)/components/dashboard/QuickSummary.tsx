'use client';
import React, { useEffect, useState } from 'react';
import { Box, CircularProgress, Grid, Typography } from '@mui/material';

type Summary = {
  total_permitidos: number;
  total_denegados: number;
  total_registros: number;
  usuarios_activos: number;
  llaves_activas: number;
};

const QuickSummary: React.FC<{dateFrom: string, dateTo: string}> = ({ dateFrom, dateTo }) => {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<Summary | null>(null);

  useEffect(() => {
    const ctrl = new AbortController();
    async function load() {
      try {
        setLoading(true);
        const p = new URLSearchParams();
        if (dateFrom) p.set('date_from', dateFrom);
        if (dateTo) p.set('date_to', dateTo);
        const res = await fetch(`/api/get_summary?${p.toString()}`, { signal: ctrl.signal });
        const json = await res.json();
        setData(json);
      } catch {
        setData(null);
      } finally {
        setLoading(false);
      }
    }
    load();
    return () => ctrl.abort();
  }, [dateFrom, dateTo]);

  if (loading || !data) {
    return <Box display="flex" alignItems="center" justifyContent="center" minHeight={120}><CircularProgress /></Box>;
  }

  return (
    <Grid container spacing={2}>
      {[
        { label: 'Permitidos', value: data.total_permitidos },
        { label: 'Denegados', value: data.total_denegados },
        { label: 'Total Registros', value: data.total_registros },
        { label: 'Usuarios Activos', value: data.usuarios_activos },
        { label: 'Llaves Activas', value: data.llaves_activas },
      ].map((k) => (
        <Grid key={k.label} item xs={6} md={4}>
          <Box p={2} sx={{ borderRadius: 2, bgcolor: 'background.default', border: '1px solid', borderColor: 'divider' }}>
            <Typography variant="body2" color="text.secondary">{k.label}</Typography>
            <Typography variant="h5" fontWeight={700}>{k.value}</Typography>
          </Box>
        </Grid>
      ))}
    </Grid>
  );
};

export default QuickSummary;
