'use client';

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AppBar, Toolbar, Box, Typography, Grid, Divider, CircularProgress, Paper,
  IconButton, Tooltip, TextField, Switch, FormControlLabel, Alert, Button, Chip,
  Stack, InputAdornment, List, ListItem, ListItemText, Select, MenuItem,
  Snackbar, Alert as MuiAlert, Avatar, Dialog, DialogTitle, DialogContent
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import DownloadIcon from '@mui/icons-material/Download';
import SearchIcon from '@mui/icons-material/Search';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import SecurityIcon from '@mui/icons-material/Security';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RTooltip,
  CartesianGrid, AreaChart, Area, XAxis, YAxis, Legend
} from 'recharts';
import BarrieControl from './barrieControl';

const API_URL = 'http://192.168.0.112:8000';
const WS_URL = 'ws://192.168.0.112:8000/ws/accesos';
const SOUND_OK = '/sounds/ok.wav';
const SOUND_DENIED = '/sounds/denied.wav';

// ==============================
// Utilidades
// ==============================
type RawRegistro = {
  id?: number | string;
  fecha?: string;
  hora?: string;
  nombre?: string;
  apellido?: string;
  dni?: string | number;
  llave?: string;
  barrera?: string;
  resultado?: string | boolean | number | null;
};

type Estado = '' | 'permitido' | 'denegado' | 'desconocido';
type KPI = { label: string; value: string | number; };

const fmtDate = (d: Date) => d.toISOString().slice(0, 10);
const maskDni = (d?: string | number) => !d ? '—' : String(d).replace(/(\d{3})\d+(\d{2})$/, '$1***$2');
const toNum = (v: any) => Number.isFinite(Number(v)) ? Number(v) : 0;

function normalizeDate(fecha?: string) {
  if (!fecha) return '';
  return fecha.includes('-') ? fecha : fecha.split('/').reverse().join('-');
}
function parseTs(fecha?: string, hora?: string): number {
  if (!fecha) return 0;
  const f = normalizeDate(fecha);
  const iso = `${f}T${hora || '00:00:00'}`;
  const t = Date.parse(iso);
  return Number.isNaN(t) ? 0 : t;
}
function normalizarResultado(v: RawRegistro['resultado']): 'permitido' | 'denegado' | 'desconocido' {
  const s = String(v ?? '').trim().toLowerCase();
  if (['permitido', 'ok', 'true', '1', 'allowed', 'success', 'aprobado'].includes(s)) return 'permitido';
  if (['denegado', 'false', '0', 'rejected', 'fail', 'denied', 'rechazado', 'error'].includes(s)) return 'denegado';
  return 'desconocido';
}
const isEntrada = (b?: string) => !!b && /_in$/i.test(b);
const isSalida = (b?: string) => !!b && /_out$/i.test(b);

// ==============================
// Componente principal
// ==============================
export default function App() {
  // --- Estados de WebSocket y notificación ---
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [noti, setNoti] = useState<{ mensaje: string; tipo: 'success' | 'error'; foto?: string; data?: any } | null>(null);
  const [modalData, setModalData] = useState<any>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // --- Filtros y datos ---
  const today = new Date();
  const startDefault = new Date(today); startDefault.setDate(startDefault.getDate() - 6);
  const [dateFrom, setDateFrom] = useState(fmtDate(startDefault));
  const [dateTo, setDateTo] = useState(fmtDate(today));
  const [q, setQ] = useState('');
  const [estado, setEstado] = useState<Estado>('');
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [maskPII, setMaskPII] = useState<boolean>(() => {
    if (typeof window === 'undefined') return true;
    return localStorage.getItem('adeco_maskPII') !== '0';
  });
  const [barFilter, setBarFilter] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [registros, setRegistros] = useState<RawRegistro[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const debounceRef = useRef<number | null>(null);

// ================== 🔔 WebSocket Push Notifications ==================
useEffect(() => {
  // Permiso para notificaciones
  if (Notification.permission !== "granted" && Notification.permission !== "denied") {
    Notification.requestPermission();
  }

  const ws = new WebSocket("ws://192.168.0.112:8000/ws/accesos");

  ws.onopen = () => console.log("🔌 WebSocket conectado con backend");

  ws.onmessage = (event) => {
    try {
      const msg = JSON.parse(event.data);
      console.log("📩 WS recibido:", msg);

      if (msg.tipo === "nuevo_evento") {
        const texto = `${msg.nombre ?? "Desconocido"} ${msg.apellido ?? ""} (${msg.estado ?? "N/A"})`;

        // ✅ Notificación del navegador
        if (Notification.permission === "granted") {
          new Notification("Nuevo acceso detectado", {
            body: texto,
            icon: msg.estado?.toLowerCase() === "permitido"
              ? "/static/icon_ok.png"
              : "/static/icon_alert.png",
          });
        }

        // 🔊 Reproducir sonido
        const audio = new Audio("/sounds/notify.wav");
        audio.play().catch(() => {});

        // 💥 Visual (toast improvisado en pantalla)
        const toast = document.createElement("div");
        toast.textContent = texto;
        toast.style.position = "fixed";
        toast.style.bottom = "20px";
        toast.style.right = "20px";
        toast.style.background = msg.estado?.toLowerCase() === "permitido" ? "#4caf50" : "#f44336";
        toast.style.color = "white";
        toast.style.padding = "12px 18px";
        toast.style.borderRadius = "6px";
        toast.style.fontWeight = "bold";
        toast.style.boxShadow = "0 2px 8px rgba(0,0,0,0.3)";
        toast.style.zIndex = "9999";
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 5000);
      }
    } catch (err) {
      console.error("⚠️ Error parseando WS:", err);
    }
  };

  ws.onclose = () => console.warn("⚠️ WebSocket desconectado del backend");

  return () => ws.close();
}, []);

// ================== 🔔 WebSocket + Notificaciones Reales ==================
useEffect(() => {
  // --- Pedir permiso al usuario ---
  if (typeof Notification !== "undefined" && Notification.permission !== "granted") {
    Notification.requestPermission();
  }

  const ws = new WebSocket("ws://192.168.0.112:8000/ws/accesos");

  ws.onopen = () => console.log("✅ WebSocket conectado al backend");

  ws.onmessage = async (event) => {
    try {
      const msg = JSON.parse(event.data);
      console.log("📩 WS recibido:", msg);

      if (!msg?.nombre) return;

      const texto = `${msg.nombre ?? "Desconocido"} ${msg.apellido ?? ""}`;
      const titulo = msg.estado === "permitido"
        ? "✅ Acceso Permitido"
        : "⛔ Acceso Denegado";

      // --- Notificación del navegador ---
      if (typeof Notification !== "undefined" && Notification.permission === "granted") {
        const iconBase64 = msg.imagen
          ? `data:image/jpeg;base64,${msg.imagen}`
          : msg.estado === "permitido"
            ? "/static/icon_ok.png"
            : "/static/icon_alert.png";

        const noti = new Notification(titulo, {
          body: `${texto} (${msg.lector ?? "Sin lector"})`,
          icon: iconBase64,
          image: iconBase64, // en algunos navegadores se muestra dentro
          badge: "/static/icon_badge.png",
          requireInteraction: true,
        });

        noti.onclick = () => {
          window.focus();
          noti.close();
        };
      }

      // --- Reproducir sonido ---
      const audio = new Audio(
        msg.estado === "permitido" ? "/sounds/ok.wav" : "/sounds/denied.wav"
      );
      audio.volume = 0.8;
      await audio.play().catch(() => {});

      // --- Mostrar toast visual (fallback si Notification no está disponible) ---
      const toast = document.createElement("div");
      toast.innerHTML = `
        <div style="
          display: flex; align-items: center; gap: 10px;
          background: ${msg.estado === "permitido" ? "#2e7d32" : "#c62828"};
          color: white; padding: 10px 16px; border-radius: 8px;
          box-shadow: 0 3px 10px rgba(0,0,0,0.3); cursor: pointer;
        ">
          ${msg.imagen
            ? `<img src="data:image/jpeg;base64,${msg.imagen}" width="48" height="48"
                style="border-radius:4px;object-fit:cover;"/>`
            : ""}
          <div>
            <div style="font-weight:bold;">${texto}</div>
            <div style="font-size:12px;opacity:.9;">${titulo}</div>
          </div>
        </div>
      `;
      toast.style.position = "fixed";
      toast.style.bottom = "20px";
      toast.style.right = "20px";
      toast.style.zIndex = "9999";
      toast.style.transition = "opacity .3s";
      document.body.appendChild(toast);
      setTimeout(() => toast.remove(), 6000);
    } catch (err) {
      console.error("⚠️ Error parseando WS:", err);
    }
  };

  ws.onclose = () => console.warn("⚠️ WebSocket desconectado");
  return () => ws.close();
}, []);


  // --- Cargar datos ---
  const fetchData = useCallback(async (signal?: AbortSignal) => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ limit: '1500' });
      if (q.trim()) params.set('q', q.trim());
      if (estado) params.set('estado', estado);
      if (dateFrom) params.set('date_from', dateFrom);
      if (dateTo) params.set('date_to', dateTo);

      const res = await fetch(`${API_URL}/get_registros.php?${params.toString()}`, { signal });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const rows = await res.json();
      setRegistros(Array.isArray(rows) ? rows : []);
    } catch (e: any) {
      if (e?.name !== 'AbortError') setError(e?.message ?? 'Error al cargar datos');
    } finally {
      setLoading(false);
    }
  }, [q, estado, dateFrom, dateTo]);

  // --- Carga inicial ---
  useEffect(() => {
    const ac = new AbortController();
    if (debounceRef.current) window.clearTimeout(debounceRef.current);
    debounceRef.current = window.setTimeout(() => { fetchData(ac.signal); }, 300);
    return () => { ac.abort(); if (debounceRef.current) window.clearTimeout(debounceRef.current); };
  }, [fetchData]);

  // --- Auto-refresh ---
  useEffect(() => {
    if (autoRefresh) {
      timerRef.current && clearInterval(timerRef.current);
      timerRef.current = setInterval(() => fetchData().catch(() => { }), 30000);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [autoRefresh, fetchData]);

  // --- WebSocket tiempo real ---
  useEffect(() => {
    const ws = new WebSocket(WS_URL);

    ws.onopen = () => console.log("📡 WebSocket conectado");
    ws.onclose = () => console.log("❌ WebSocket cerrado");
    ws.onerror = (e) => console.error("⚠️ Error WS:", e);

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.tipo === "nuevo_evento") {
          console.log("🔔 Evento recibido:", data);

          if (audioRef.current) {
            audioRef.current.src = data.estado === "permitido" ? SOUND_OK : SOUND_DENIED;
            audioRef.current.play().catch(() => { });
          }

          setNoti({
            mensaje: `${data.nombre ?? "Desconocido"} ${data.apellido ?? ""} - ${data.estado.toUpperCase()} (${data.lector})`,
            tipo: data.estado === "permitido" ? "success" : "error",
            foto: data.imagen ? `data:image/jpeg;base64,${data.imagen}` : undefined,
            data
          });

          fetchData().catch(() => { });
        }
      } catch (err) {
        console.error("❌ Error parseando mensaje WS:", err);
      }
    };

    setSocket(ws);
    return () => ws.close();
  }, [fetchData]);

  // ======================
  // Renderizado visual
  // ======================
  const total = registros.length;
  const permitidos = registros.filter(r => normalizarResultado(r.resultado) === 'permitido').length;
  const denegados = registros.filter(r => normalizarResultado(r.resultado) === 'denegado').length;
  const pctOk = total ? Math.round((permitidos / total) * 100) : 0;

  const kpis: KPI[] = [
    { label: 'Eventos', value: total },
    { label: 'Permisos', value: `${pctOk}%` },
    { label: 'Denegados', value: denegados }
  ];

  const pieData = useMemo(() => [
    { name: 'Permitidos', value: permitidos },
    { name: 'Denegados', value: denegados }
  ], [permitidos, denegados]);

  const PIE_COLORS = ['#2e7d32', '#c62828'];

  // ======================
  // Render
  // ======================
  return (
    <Box sx={{ minHeight: '100vh', bgcolor: (t) => t.palette.grey[50] }}>
      <AppBar elevation={0} color="default" position="sticky" sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Toolbar sx={{ gap: 2, flexWrap: 'wrap' }}>
          <Typography variant="h6" sx={{ fontWeight: 700, flexGrow: 1, display: 'flex', alignItems: 'center', gap: 1 }}>
            <SecurityIcon /> ADECO • Control de Accesos
          </Typography>
        </Toolbar>
      </AppBar>

      <Box sx={{ p: 3 }}>
        {loading ? (
          <Box display="flex" justifyContent="center" alignItems="center" height={260}>
            <CircularProgress />
          </Box>
        ) : (
          <>
            <Grid container spacing={2} mb={2}>
              {kpis.map(k => (
                <Grid item xs={12} sm={4} key={k.label}>
                  <Paper sx={{ p: 2 }}>
                    <Typography variant="overline">{k.label}</Typography>
                    <Typography variant="h5" fontWeight={700}>{k.value}</Typography>
                  </Paper>
                </Grid>
              ))}
            </Grid>

            <Grid container spacing={2}>
              <Grid item xs={12} md={4}>
                <Paper sx={{ p: 2 }}>
                  <Typography variant="h6">Estado de Accesos</Typography>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie data={pieData} dataKey="value" nameKey="name" innerRadius={60} outerRadius={90}>
                        {pieData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % 2]} />)}
                      </Pie>
                      <RTooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </Paper>
              </Grid>

              <Grid item xs={12} md={8}>
                <Paper sx={{ p: 2 }}>
                  <Typography variant="h6">Últimos registros</Typography>
                 
                </Paper>
              </Grid>
            </Grid>
          </>
        )}
      </Box>

      {/* --- AUDIO --- */}
      <audio ref={audioRef} />

      {/* --- SNACKBAR --- */}
      <Snackbar
        open={!!noti}
        autoHideDuration={4000}
        onClose={() => setNoti(null)}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        {noti && (
          <MuiAlert
            severity={noti.tipo}
            variant="filled"
            sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}
            action={
              <Button color="inherit" size="small" onClick={() => setModalData(noti.data)}>
                Ver detalle
              </Button>
            }
          >
            {noti.foto && <Avatar src={noti.foto} sx={{ width: 40, height: 40, border: '2px solid white' }} />}
            {noti.mensaje}
          </MuiAlert>
        )}
      </Snackbar>

      {/* --- MODAL DETALLE --- */}
      <Dialog open={!!modalData} onClose={() => setModalData(null)} maxWidth="sm" fullWidth>
        {modalData && (
          <>
            <DialogTitle>{modalData.nombre} {modalData.apellido}</DialogTitle>
            <DialogContent>
              {modalData.imagen && (
                <Box display="flex" justifyContent="center" mb={2}>
                  <img src={`data:image/jpeg;base64,${modalData.imagen}`} alt="Captura" style={{ width: '100%', borderRadius: 8 }} />
                </Box>
              )}
              <Typography><b>DNI:</b> {modalData.dni}</Typography>
              <Typography><b>Lector:</b> {modalData.lector}</Typography>
              <Typography><b>Estado:</b> {modalData.estado}</Typography>
              <Typography><b>Fecha:</b> {modalData.fecha}</Typography>
            </DialogContent>
          </>
        )}
      </Dialog>
    </Box>
  );
}
