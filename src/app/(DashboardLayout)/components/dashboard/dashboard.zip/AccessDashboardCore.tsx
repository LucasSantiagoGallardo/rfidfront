'use client';

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  Box, Typography, Grid, CircularProgress, Paper, Divider, 
  FormControlLabel, Switch
} from '@mui/material';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RTooltip
} from 'recharts';

const FASTAPI_URL = process.env.NEXT_PUBLIC_FASTAPI_URL;
const WEBSOCKET_URL = process.env.NEXT_PUBLIC_WEBSOCKET_URL;

interface Registro {
  id: number;
  dni: string; 
  nombre: string;
  apellido: string;
  lector: string;
  estado: 'PERMITIDO' | 'DENEGADO' | 'ERROR';
  fecha: string; 
  imagen_base64?: string;
}

interface Kpis {
    total: number;
    permitidos: number;
    denegados: number;
    porcentajePermitidos: number;
}

interface AccessDashboardCoreProps {
    filters: URLSearchParams;
    onNewRealTimeEvent: (event: Registro) => void; 
}

export default function AccessDashboardCore({ filters, onNewRealTimeEvent }: AccessDashboardCoreProps) {
  const [registros, setRegistros] = useState<Registro[]>([]);
  const [loading, setLoading] = useState(true);
  const [kpis, setKpis] = useState<Kpis>({ total: 0, permitidos: 0, denegados: 0, porcentajePermitidos: 0 });
  const [maskPII, setMaskPII] = useState(() => localStorage.getItem('maskPII') === 'true');
  
  // Función helper para enmascarar (asegúrese de que esta función exista o se defina aquí)
  const maskDni = (dni: string) => {
    return dni ? dni.substring(0, 3) + '***' : 'N/A';
  }

  // Persistir estado de máscara
  useEffect(() => { localStorage.setItem('maskPII', String(maskPII)); }, [maskPII]);

  // A. Fetching de Datos Históricos (sin cambios)
  const fetchData = useCallback(async () => {
    setLoading(true);
    const url = `${FASTAPI_URL}/accesos?${filters.toString()}`;
    
    try {
      const res = await fetch(url);
      const data: Registro[] = await res.json();
      setRegistros(data); 
      setLoading(false);
    } catch (error) {
      console.error('Error fetching data:', error);
      setLoading(false);
    }
  }, [filters]);

  // B. Conexión WebSocket (sin cambios)
  useEffect(() => {
    if (!WEBSOCKET_URL) return;

    const ws = new WebSocket(WEBSOCKET_URL);

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.tipo === 'nuevo_evento') {
        const newEvent: Registro = data.payload || data;
        
        // 1. Integrar inmediatamente en la tabla (LIVE FEED)
        setRegistros(prevRegistros => {
          const registroParaTabla = { ...newEvent, id: newEvent.id || Date.now() }; 
          return [registroParaTabla, ...prevRegistros.slice(0, 1499)];
        });

        // 2. Disparar el callback para que el padre muestre el Snackbar
        onNewRealTimeEvent(newEvent); 
      }
    };

    return () => ws.close();
  }, [onNewRealTimeEvent]);


  // C. Cálculo de KPIs (sin cambios)
  useEffect(() => {
    if (registros.length > 0) {
      const total = registros.length;
      const permitidos = registros.filter(r => r.estado === 'PERMITIDO').length;
      const denegados = total - permitidos;
      const porcentajePermitidos = total > 0 ? (permitidos / total) * 100 : 0;
      setKpis({ total, permitidos, denegados, porcentajePermitidos });
    } else {
      setKpis({ total: 0, permitidos: 0, denegados: 0, porcentajePermitidos: 0 });
    }
  }, [registros]);
  
  // D. Inicialización
  useEffect(() => { fetchData(); }, [fetchData]);


  // Definición de columnas de la tabla (FIX aplicado aquí)
  const columns: GridColDef[] = useMemo(() => [
    { field: 'id', headerName: 'ID', width: 80 },
    { field: 'fecha', headerName: 'Fecha y Hora', width: 180 }, 
    { 
        field: 'dni', 
        headerName: 'DNI', 
        width: 150, 
        // ✅ FIX: Control de seguridad para evitar 'undefined (reading dni)'
        valueGetter: (params) => {
            // Aseguramos que params.row exista y que dni exista
            const dniValue = params.row?.dni; 
            if (!dniValue) {
                return 'N/A'; // Valor por defecto si la fila es incompleta
            }
            return maskPII ? maskDni(dniValue) : dniValue;
        }
    },
    { field: 'nombre', headerName: 'Nombre', width: 150 },
    { field: 'apellido', headerName: 'Apellido', width: 150 },
    { field: 'lector', headerName: 'Lector', width: 120 },
    { 
        field: 'estado', 
        headerName: 'Estado', 
        width: 120,
        renderCell: (params) => (
            <Typography color={params.value === 'PERMITIDO' ? 'success.main' : 'error.main'} fontWeight="bold">
                {params.value}
            </Typography>
        )
    },
    { field: 'epc', headerName: 'EPC/Key ID', width: 200 },
  ], [maskPII]);


  return (
    <Box>
      {/* Indicador de carga */}
      {loading && <CircularProgress sx={{ display: 'block', mx: 'auto', my: 2 }} />}
      
      {/* KPIs DE ACCESO (sin cambios) */}
      <Grid container spacing={2} mb={3}>
        {/* ... (Kpis) ... */}
      </Grid>
      
      <Grid container spacing={2}>
        {/* GRÁFICO DE ESTADO Y OPCIONES (sin cambios) */}
        <Grid item xs={12} md={4}>
           {/* ... */}
        </Grid>

        {/* TABLA UNIFICADA DE REGISTROS (LIVE FEED) */}
        <Grid item xs={12} md={8}>
          <Paper elevation={3} sx={{ p: 2, height: 600 }}>
            <Typography variant="h6" mb={2}>Feed de Accesos en Vivo ({registros.length} / 1500)</Typography>
            <Box sx={{ height: 500, width: '100%' }}>
              <DataGrid
                rows={registros}
                columns={columns}
                pageSizeOptions={[10, 25, 50]}
                disableRowSelectionOnClick
                loading={loading}
                // Si tienes problemas de rendimiento con el live feed, añade getRowId
                // getRowId={(row) => row.id}
              />
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}